package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.entities.Employee;
import com.virtusa.integrate.ConnectionManager;

public class HrDAOImpl implements HrDAO {

	@Override
	public Employee getManager(int deptid) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("select employeeid,designation\r\n"+
				"from employee\r\n"+
				"where deptid=?;"
				);
		statement.setInt(1, deptid);
		ResultSet resultSet=statement.executeQuery();
		Employee employee=new Employee();
		while(resultSet.next()) {
			
			employee.setEmployeeId(resultSet.getInt("employeeId"));
			employee.setDesignation(resultSet.getString("designation"));
			
		}
		ConnectionManager.closeConnection();
		return employee;
	}

}
