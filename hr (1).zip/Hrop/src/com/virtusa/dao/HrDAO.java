package com.virtusa.dao;

import java.sql.SQLException;

import com.virtusa.entities.Employee;

public interface HrDAO {

	public Employee getManager(int deptid)throws ClassNotFoundException, SQLException;
}
