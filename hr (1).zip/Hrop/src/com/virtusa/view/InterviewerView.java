package com.virtusa.view;

public class InterviewerView {
	public void interviewerView() {
		System.out.println("=======Interviewer View======");
	}
}
