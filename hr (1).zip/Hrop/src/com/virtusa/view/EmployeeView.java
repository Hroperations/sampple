package com.virtusa.view;

import com.virtusa.model.HrModel;

public class EmployeeView {
	
	private HrView hrview=new HrView();

	public void showManager(HrModel hr) {
		
	System.out.println(hr.getEmployeeId()+"  "+hr.getDesignation());
	
		hrview.hrView();
	}

}
