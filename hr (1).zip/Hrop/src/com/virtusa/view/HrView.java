package com.virtusa.view;

import java.util.Scanner;

import com.virtusa.controller.HrController;

public class HrView {
	public void hrView() {
		System.out.println("=======Hr View======");
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("1.View Application");
		System.out.println("2.Send Application Status");
		System.out.println("3.Assign Manager");
		System.out.println("4.Send Interview Details To Applicant");
		System.out.println("5.Send Result Update");
		System.out.println("6. Generate Offer Letter");
		System.out.print("Enter option:");
		
		int option=scanner.nextInt();
		HrView hrView=new HrView();
		if(option==1)
		  hrView.viewApplication();
		else if(option==2)
			hrView.sendApplicationStatus();
		else if(option==3)
			hrView.assignManager();
		else if(option==4)
			hrView.sendInterviewDetailsToApplicant();
		else if(option==5)
			hrView.sendResultUpdate();
		else
			hrView.generateOfferLetter();
		
	}

	private void generateOfferLetter() {
		// TODO Auto-generated method stub
		
	}

	private void sendResultUpdate() {
		// TODO Auto-generated method stub
		
	}

	private void sendInterviewDetailsToApplicant() {
		// TODO Auto-generated method stub
		
	}

	private void assignManager() {
		HrController hrController=new HrController();
		  
		  try(Scanner scanner=new Scanner(System.in);){
			  System.out.print("Please Enter Department Id:");
			  int deptId=scanner.nextInt();
		      hrController.retrieveManager(deptId);
			  
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
	       
		
	}

	private void sendApplicationStatus() {
		// TODO Auto-generated method stub
		
	}

	private void viewApplication() {
		// TODO Auto-generated method stub
		
	}
}
