package com.virtusa.controller;

import com.virtusa.factory.FactoryHrService;
import com.virtusa.model.HrModel;
import com.virtusa.service.HrService;
import com.virtusa.view.EmployeeView;

public class HrController {
	private HrService hrService;
	EmployeeView employeeView=new EmployeeView();
	
	public HrController() {
		this.hrService=
				FactoryHrService.createHrService();
	}
	public void retrieveManager(int deptId) {
		HrModel hr=hrService.retrieveManager(deptId);
	
		employeeView.showManager(hr);
		
	}
}
