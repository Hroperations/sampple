package com.virtusa.service;

import java.util.List;

import com.virtusa.model.AdminModel;

public interface ApplicantService {
	public List<AdminModel> retrieveJobService();
	
}
