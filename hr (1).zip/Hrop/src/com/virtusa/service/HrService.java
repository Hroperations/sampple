package com.virtusa.service;

import com.virtusa.model.HrModel;

public interface HrService {

	HrModel retrieveManager(int deptId);

}
