package com.virtusa.service;

import java.sql.SQLException;

import com.virtusa.dao.HrDAO;
import com.virtusa.entities.Employee;
import com.virtusa.factory.FactoryHrDAO;
import com.virtusa.model.HrModel;

public class HrServiceImpl implements HrService {

	private HrDAO hrDAO;
	public HrServiceImpl() {
		this.hrDAO=FactoryHrDAO.createHrDAO();
	}
	@Override
	public HrModel retrieveManager(int deptId) {
		// TODO Auto-generated method stub
		Employee employee=null;
		HrModel hrModel=new HrModel();
		try {
			employee=hrDAO.getManager(deptId);
			hrModel.setEmployeeId(employee.getEmployeeId());
			hrModel.setDesignation(employee.getDesignation());
			
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return hrModel;
	}

}
